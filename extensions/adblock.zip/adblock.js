(function() {
    const blocked = ["doubleclick.net","googlesyndication.com","googleadservices.com","adservice.google.com","pagead2.googlesyndication.com","amazon-adsystem.com"];
    setInterval(() => {
        document.querySelectorAll('iframe, script, img, [src]').forEach(el => {
            const src = el.src || el.href || '';
            if (blocked.some(d => src.includes(d))) el.remove();
        });
        document.querySelectorAll('[id*="ad-"], [class*="ad-"], [id*="sponsor"], [class*="sponsor"], .adsbygoogle, ins.adsbygoogle').forEach(el => el.remove());
    }, 2000);
})();