// 🦍 Gorilla Cursor Extension for RealGorilla Browser
(function() {
    // Create a gorilla hand cursor using CSS
    const style = document.createElement('style');
    style.textContent = `
        * {
            cursor: url("data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><text font-size="28" y="28">🦍</text></svg>')}") 16 16, auto !important;
        }
        a, button, input, select, [onclick], .clickable {
            cursor: url("data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><text font-size="28" y="28">👆</text></svg>')}") 16 16, pointer !important;
        }
        a:hover, button:hover {
            cursor: url("data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><text font-size="28" y="28">🖐️</text></svg>')}") 16 16, pointer !important;
        }
    `;
    document.head.appendChild(style);
    console.log('🦍 Gorilla Cursor activated!');
})();