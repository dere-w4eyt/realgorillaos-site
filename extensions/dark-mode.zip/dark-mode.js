(function() {
    const style = document.createElement('style');
    style.textContent = 'html{filter:invert(1)hue-rotate(180deg)!important}img,video,canvas{filter:invert(1)hue-rotate(180deg)!important}';
    document.head.appendChild(style);
})();